// ── Estado ────────────────────────────────────────────────
let moviendose    = false;
let timerContinuo = null;
let botonActual   = null;
let bloqueado     = false;   // controlado por el sensor

// ── Helpers ───────────────────────────────────────────────
function getCm() {
  const v = parseInt(document.getElementById('cm-input').value, 10);
  return isNaN(v) || v < 0 ? 0 : v;
}

function ajustarCm(delta) {
  const input = document.getElementById('cm-input');
  const nuevo = Math.max(0, Math.min(999, (parseInt(input.value) || 0) + delta));
  input.value = nuevo;
}

function setBadge(texto, tipo) {
  const b = document.getElementById('estado-badge');
  b.textContent = texto;
  b.className = 'badge badge-' + tipo;
}

function log(msg, tipo = 'info') {
  const box = document.getElementById('log');
  const t = new Date().toLocaleTimeString('es-CL', { hour12: false });
  const div = document.createElement('div');
  div.className = 'log-' + tipo;
  div.textContent = `[${t}] ${msg}`;
  box.prepend(div);
  while (box.children.length > 30) box.removeChild(box.lastChild);
}

// ── Actualizar UI del sensor ──────────────────────────────
function actualizarSensor(distancia, esBloqueado) {
  const distEl   = document.getElementById('distancia-valor');
  const barraEl  = document.getElementById('distancia-barra');
  const sensorEl = document.getElementById('sensor-panel');
  const btnAd    = document.getElementById('btn-adelante');

  // Mostrar distancia
  const texto = distancia >= 200 ? '— cm' : `${distancia} cm`;
  distEl.textContent = texto;

  // Barra de distancia (0-100cm → 0-100%)
  const pct = Math.min(100, Math.max(0, ((distancia >= 200 ? 200 : distancia) / 200) * 100));
  barraEl.style.width = pct + '%';

  // Color de la barra según distancia
  if (distancia < 20) {
    barraEl.style.background = '#ff3030';
  } else if (distancia < 40) {
    barraEl.style.background = '#ffaa00';
  } else {
    barraEl.style.background = '#00ff88';
  }

  // Bloquear / desbloquear botón adelante
  if (esBloqueado && !bloqueado) {
    bloqueado = true;
    btnAd.classList.add('bloqueado');
    btnAd.disabled = true;
    sensorEl.classList.add('alerta');
    setBadge('⚠ OBSTÁCULO', 'error');
    log('⚠ Obstáculo detectado — adelante bloqueado', 'error');
    // Si estaba yendo adelante, parar
    if (moviendose && botonActual === btnAd) {
      soltarBoton();
    }
  } else if (!esBloqueado && bloqueado) {
    bloqueado = false;
    btnAd.classList.remove('bloqueado');
    btnAd.disabled = false;
    sensorEl.classList.remove('alerta');
    setBadge('LIBRE', 'idle');
    log('✅ Camino libre — adelante desbloqueado', 'ok');
  }
}

// ── Polling del sensor cada 500ms ────────────────────────
async function pollSensor() {
  try {
    const res  = await fetch('/sensor');
    const data = await res.json();
    if (data.ok) actualizarSensor(data.distancia, data.bloqueado);
  } catch (_) { /* silencioso */ }
}
setInterval(pollSensor, 500);
pollSensor(); // primera lectura inmediata

// ── Enviar comando al servidor ────────────────────────────
async function enviar(direccion, cm) {
  // Bloqueo local: no enviar adelante si está bloqueado
  if (direccion === 'adelante' && bloqueado) return;

  try {
    const res  = await fetch('/mover', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ direccion, cm }),
    });
    const data = await res.json();

    if (!res.ok || !data.ok) {
      if (data.error === 'bloqueado') return; // silencioso, ya se muestra en sensor
      throw new Error(data.error || 'Error desconocido');
    }

    if (direccion === 'parar') {
      setBadge('DETENIDO', 'idle');
      log('⏹ Detenido', 'info');
    } else {
      setBadge('MOVIENDO', 'moving');
      const cmStr = cm > 0 ? ` (${cm} cm)` : ' continuo';
      log(`▶ ${direccion.toUpperCase()}${cmStr}`, 'ok');
    }

  } catch (err) {
    setBadge('ERROR', 'error');
    log('❌ ' + err.message, 'error');
  }
}

// ── Manejo de botones ─────────────────────────────────────
function iniciarMovimiento(direccion) {
  if (direccion === 'adelante' && bloqueado) return;

  const cm    = getCm();
  const btnId = 'btn-' + direccion;
  const btn   = document.getElementById(btnId);

  if (botonActual) botonActual.classList.remove('presionado');
  botonActual = btn;
  btn.classList.add('presionado');

  if (cm > 0) {
    moviendose = true;
    enviar(direccion, cm).then(() => {
      const ms = (cm / 20) * 1000 + 400;
      setTimeout(() => {
        setBadge('DETENIDO', 'idle');
        if (botonActual) botonActual.classList.remove('presionado');
        botonActual = null;
        moviendose  = false;
      }, ms);
    });
  } else {
    moviendose = true;
    enviar(direccion, 0);
    timerContinuo = setInterval(() => enviar(direccion, 0), 1500);
  }
}

function soltarBoton() {
  clearInterval(timerContinuo);
  timerContinuo = null;
  moviendose = false;
  if (botonActual) botonActual.classList.remove('presionado');
  botonActual = null;
  enviar('parar', 0);

// ── Teclado ───────────────────────────────────────────────
const teclaMap = {
  'ArrowUp':    'adelante',
  'ArrowDown':  'atras',
  'ArrowLeft':  'izquierda',
  'ArrowRight': 'derecha',
};
const teclasPresionadas = new Set();

document.addEventListener('keydown', (e) => {
  const dir = teclaMap[e.key];
  if (dir && !teclasPresionadas.has(e.key)) {
    teclasPresionadas.add(e.key);
    iniciarMovimiento(dir);
  }
  if (e.key === ' ') { e.preventDefault(); enviar('parar', 0); }
});
document.addEventListener('keyup', (e) => {
  const dir = teclaMap[e.key];
  if (dir) { teclasPresionadas.delete(e.key); soltarBoton(); }
});

// ── Init ──────────────────────────────────────────────────
log('Sistema listo 🤖 — sensor activo', 'ok');
