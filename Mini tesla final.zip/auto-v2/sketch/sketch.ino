// ============================================================
//  Robot Control - Motores + Matriz LEDs + Sensor Ultrasónico
//  Motores L298N Mini:  IN1=2, IN2=3 (motor derecho)
//                       IN3=4, IN4=5 (motor izquierdo)
//  Sensor HC-SR04:      TRIG=9, ECHO=10
//
//  Lógica de seguridad:
//    - Si distancia < DISTANCIA_MINIMA_CM → para y bloquea "adelante"
//    - Si distancia >= DISTANCIA_SEGURA_CM → desbloquea "adelante"
//    - La distancia se publica al Python vía Bridge cada 200ms
// ============================================================

#include <Arduino_LED_Matrix.h>
#include <Arduino_RouterBridge.h>

// ── Pines motores ─────────────────────────────────────────────
#define IN1 2
#define IN2 3
#define IN3 4
#define IN4 5

// ── Pines sensor ──────────────────────────────────────────────
#define TRIG 9
#define ECHO 10

// ── Umbrales de distancia (cm) ────────────────────────────────
#define DISTANCIA_MINIMA_CM  20   // Menos de esto → frena y bloquea adelante
#define DISTANCIA_SEGURA_CM  25   // Más de esto   → desbloquea adelante
#define DISTANCIA_MAXIMA_CM 200   // Más de esto se considera "sin obstáculo"

// ── Patrones de LEDs ──────────────────────────────────────────
uint8_t LED_Adelante[104] = {
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,7,7,7,0,0,0,0,0,
  0,0,0,0,7,7,7,7,7,0,0,0,0,
  0,0,0,7,0,0,7,0,0,7,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0
};
uint8_t LED_Atras[104] = {
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,7,0,0,7,0,0,7,0,0,0,
  0,0,0,0,7,7,7,7,7,0,0,0,0,
  0,0,0,0,0,7,7,7,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0
};
uint8_t LED_Der[104] = {
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,7,0,0,0,0,
  0,0,0,0,0,0,0,0,7,7,0,0,0,
  0,0,7,7,7,7,7,7,7,7,7,0,0,
  0,0,7,7,7,7,7,7,7,7,7,0,0,
  0,0,0,0,0,0,0,0,7,7,0,0,0,
  0,0,0,0,0,0,0,0,7,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0
};
uint8_t LED_Izq[104] = {
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,7,0,0,0,0,0,0,0,0,
  0,0,0,7,7,0,0,0,0,0,0,0,0,
  0,0,7,7,7,7,7,7,7,7,7,0,0,
  0,0,7,7,7,7,7,7,7,7,7,0,0,
  0,0,0,7,7,0,0,0,0,0,0,0,0,
  0,0,0,0,7,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0
};
uint8_t LED_Stop[104] = {
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,7,7,7,7,7,7,7,7,7,0,0,
  0,0,7,0,0,0,0,0,0,0,7,0,0,
  0,0,7,0,7,7,7,7,7,0,7,0,0,
  0,0,7,0,7,7,7,7,7,0,7,0,0,
  0,0,7,0,0,0,0,0,0,0,7,0,0,
  0,0,7,7,7,7,7,7,7,7,7,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0
};
// LED de advertencia: signo de exclamación
uint8_t LED_Warn[104] = {
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0
};

// ── Estado ────────────────────────────────────────────────────
Arduino_LED_Matrix matrix;
int   tiempoMovimiento = 0;
unsigned long ultimoTick     = 0;
unsigned long ultimoSensor   = 0;
char  movimientoActual = 'S';
bool  bloqueado        = false;   // true = adelante bloqueado por obstáculo
int   distanciaActual  = 999;     // cm, publicada al Python

// ── Funciones motor ───────────────────────────────────────────
void detener() {
  digitalWrite(IN1, LOW); digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW); digitalWrite(IN4, LOW);
}
void adelante() {
  digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);  digitalWrite(IN4, HIGH);
}
void atras() {
  digitalWrite(IN1, LOW);  digitalWrite(IN2, HIGH);
  digitalWrite(IN3, HIGH); digitalWrite(IN4, LOW);
}
void girarDer() {
  digitalWrite(IN1, LOW);  digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);  digitalWrite(IN4, HIGH);
}
void girarIzq() {
  digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);  digitalWrite(IN4, LOW);
}
void mostrarLED(uint8_t* patron) {
  matrix.setGrayscaleBits(3);
  matrix.draw(patron);
}

// ── Medir distancia ───────────────────────────────────────────
int medirDistancia() {
  digitalWrite(TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG, LOW);

  unsigned long dur = pulseIn(ECHO, HIGH, 30000);
  if (dur == 0 || dur > 30000) return 999; // sin objeto / fuera de rango
  return (int)(dur / 58);
}

// ── Recibir comando desde Python ──────────────────────────────
void recibir_comando(String cmd) {
  if (cmd.length() == 0) return;

  int  separador = cmd.indexOf(':');
  char accion    = cmd[0];
  tiempoMovimiento = 0;

  if (separador > 0) {
    tiempoMovimiento = cmd.substring(separador + 1).toInt();
  }

  // Si está bloqueado e intenta ir adelante → ignorar
  if (bloqueado && accion == 'F') return;

  movimientoActual = accion;
  ultimoTick = millis();

  switch (accion) {
    case 'F': adelante();  mostrarLED(LED_Adelante); break;
    case 'B': atras();     mostrarLED(LED_Atras);    break;
    case 'R': girarDer();  mostrarLED(LED_Der);      break;
    case 'L': girarIzq();  mostrarLED(LED_Izq);      break;
    case 'S': default:
      detener();
      mostrarLED(bloqueado ? LED_Warn : LED_Stop);
      tiempoMovimiento = 0;
      movimientoActual = 'S';
      break;
  }
}

// ── Setup ─────────────────────────────────────────────────────
void setup() {
  pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  pinMode(TRIG, OUTPUT);
  pinMode(ECHO, INPUT);
  detener();

  matrix.begin();
  matrix.setGrayscaleBits(3);
  mostrarLED(LED_Stop);

  Bridge.begin();
  Bridge.provide("recibir_comando", recibir_comando);
}

// ── Loop ──────────────────────────────────────────────────────
void loop() {
  unsigned long ahora = millis();

  // 1. Leer sensor cada 200ms
  if (ahora - ultimoSensor >= 200) {
    ultimoSensor = ahora;
    distanciaActual = medirDistancia();

    // ── Lógica de bloqueo ──────────────────────────────────
    if (!bloqueado && distanciaActual < DISTANCIA_MINIMA_CM) {
      bloqueado = true;
      // Si estaba yendo adelante, frenar inmediatamente
      if (movimientoActual == 'F') {
        detener();
        mostrarLED(LED_Warn);
        movimientoActual = 'S';
        tiempoMovimiento = 0;
      }
    } else if (bloqueado && distanciaActual >= DISTANCIA_SEGURA_CM) {
      bloqueado = false;
      mostrarLED(LED_Stop);
    }

    // Enviar distancia + estado al Python via Bridge.call
    Bridge.call("actualizar_sensor", String(distanciaActual) + "," + String(bloqueado ? 1 : 0));
  }

  // 2. Auto-parar cuando vence el tiempo
  if (tiempoMovimiento > 0 && movimientoActual != 'S') {
    if ((ahora - ultimoTick) >= (unsigned long)tiempoMovimiento) {
      detener();
      mostrarLED(bloqueado ? LED_Warn : LED_Stop);
      movimientoActual = 'S';
      tiempoMovimiento = 0;
    }
  }
}
