from arduino.app_bricks.web_ui import WebUI
from arduino.app_utils import App, Bridge, Logger

logger = Logger("robot-control")

ui = WebUI(
    port=7000,
    assets_dir_path="./web",
)

logger.info("Servidor Robot Control con sensor iniciado en puerto 7000")

CM_POR_SEGUNDO = 20.0

COMANDOS = {
    "adelante":  "F",
    "atras":     "B",
    "derecha":   "R",
    "izquierda": "L",
    "parar":     "S",
}

# ── Estado del sensor (actualizado por el sketch vía Bridge) ──
estado_sensor = {"distancia": 999, "bloqueado": False}


# ── Callback: el sketch llama a esto cada 200ms con la distancia ─
def actualizar_sensor(valor: str):
    """
    Recibe "distancia_cm,bloqueado" ej: "15,1" o "80,0"
    """
    try:
        partes = valor.split(",")
        estado_sensor["distancia"] = int(partes[0])
        estado_sensor["bloqueado"] = partes[1].strip() == "1"
    except Exception:
        pass

Bridge.provide("actualizar_sensor", actualizar_sensor)


# ── Endpoint: el frontend consulta esto cada 500ms ────────────
def get_sensor(_payload: dict):
    return {
        "ok":        True,
        "distancia": estado_sensor["distancia"],
        "bloqueado": estado_sensor["bloqueado"],
    }


# ── Endpoint: mover el robot ──────────────────────────────────
def mover(payload: dict):
    direccion = payload.get("direccion", "parar")
    cm        = float(payload.get("cm", 0))

    if direccion not in COMANDOS:
        return {"ok": False, "error": f"Dirección '{direccion}' no reconocida"}

    # Seguridad extra en Python: no enviar F si está bloqueado
    if direccion == "adelante" and estado_sensor["bloqueado"]:
        return {"ok": False, "error": "bloqueado", "distancia": estado_sensor["distancia"]}

    letra = COMANDOS[direccion]

    if letra == "S" or cm <= 0:
        cmd = letra
    else:
        ms = int((cm / CM_POR_SEGUNDO) * 1000)
        cmd = f"{letra}:{ms}"

    logger.info(f"Enviando: {cmd}")
    Bridge.call("recibir_comando", cmd)

    return {"ok": True, "comando": cmd}


ui.expose_api("POST", "/mover",   mover)
ui.expose_api("GET",  "/sensor",  get_sensor)

App.run()
