#define IN1 2
#define IN2 3
#define IN3 4
#define IN4 5

void setup() {

  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);

  pinMode(IN3, OUTPUT);
  pinMode(IN4, OUTPUT);
}

void loop() {

  // Motor derecho adelante
  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);

  // Motor izquierdo adelante
  digitalWrite(IN3, HIGH);
  digitalWrite(IN4, LOW);
}