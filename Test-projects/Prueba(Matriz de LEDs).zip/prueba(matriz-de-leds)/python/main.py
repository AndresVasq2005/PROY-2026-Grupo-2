from arduino.app_bricks.web_ui import WebUI
from arduino.app_utils import App, Bridge, Logger

logger = Logger("prueba-matriz-leds")

# Inicializar la Web UI
ui = WebUI(
    port=7000,
    assets_dir_path="./web",
)

logger.info("Servidor de Matriz de LEDs iniciado")

# Modos disponibles con su letra de comando para el Arduino
MODOS = {
    "A": "Cara Feliz",
    "B": "Pacman",
    "C": "Sí",
    "D": "No",
}


def enviar(payload: dict):
    """Recibe la letra del modo y la envía al Arduino por el Bridge."""
    texto = payload.get("texto", "")

    if texto not in MODOS:
        logger.warning(f"Modo desconocido recibido: '{texto}'")
        return {"ok": False, "error": f"Modo '{texto}' no reconocido"}

    logger.info(f"Enviando modo: {texto} ({MODOS[texto]})")
    Bridge.call("recibir_comando", texto)

    return {"ok": True, "modo": MODOS[texto]}


ui.expose_api("POST", "/enviar", enviar)

App.run()