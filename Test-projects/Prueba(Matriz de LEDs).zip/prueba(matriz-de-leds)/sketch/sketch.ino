#include <Arduino_LED_Matrix.h>
#include <Arduino_RouterBridge.h>

// --- Patrones de LEDs (8 filas x 13 columnas = 104 píxeles) ---
// Cada número es la intensidad: 0 = apagado, 7 = máximo brillo

uint8_t LED_CaraFeliz[104] = {
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,7,7,0,0,0,0,0,0,0,7,7,0,
  0,7,7,0,0,0,0,0,0,0,7,7,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,7,0,0,0,0,0,7,0,0,0,
  0,0,0,0,7,0,0,0,7,0,0,0,0,
  0,0,0,0,0,7,7,7,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0
};

uint8_t LED_PacMan[104] = {
  0,0,0,0,7,7,7,7,0,0,0,0,0,
  0,0,0,7,7,7,7,7,7,0,0,0,0,
  0,0,7,7,7,7,7,7,7,7,0,0,0,
  0,7,7,7,7,7,0,0,0,0,0,0,0,
  0,7,7,7,7,7,0,0,0,0,0,0,0,
  0,0,7,7,7,7,7,7,7,7,0,0,0,
  0,0,0,7,7,7,7,7,7,0,0,0,0,
  0,0,0,0,7,7,7,7,0,0,0,0,0
};

uint8_t LED_si[104] = {
  0,0,0,0,2,7,7,7,2,0,0,0,0,
  0,0,0,2,7,2,2,2,7,2,0,0,0,
  0,0,2,7,2,0,0,0,2,7,2,0,0,
  0,0,2,7,2,0,0,0,2,7,2,0,0,
  0,0,2,7,2,0,0,0,2,7,2,0,0,
  0,0,2,7,2,0,0,0,2,7,2,0,0,
  0,0,0,2,7,2,2,2,7,2,0,0,0,
  0,0,0,0,2,7,7,7,2,0,0,0,0
};

uint8_t LED_no[104] = {
  0,0,0,7,2,0,0,0,2,7,0,0,0,
  0,0,0,2,7,2,0,2,7,2,0,0,0,
  0,0,0,0,2,7,2,7,2,0,0,0,0,
  0,0,0,0,0,2,7,2,0,0,0,0,0,
  0,0,0,0,0,2,7,2,0,0,0,0,0,
  0,0,0,0,2,7,2,7,2,0,0,0,0,
  0,0,0,2,7,0,0,2,7,2,0,0,0,
  0,0,0,7,2,0,0,0,2,7,0,0,0
};

Arduino_LED_Matrix matrix;

// --- Función para dibujar un patrón en la matriz ---
void drawInMatrix(uint8_t matrixLED[], int ledIntensity) {
  matrix.setGrayscaleBits(ledIntensity); // Intensidad de luz (1-8 bits)
  matrix.draw(matrixLED);               // Dibuja el patrón
}

// --- Proveedor Bridge: recibe el comando desde Python ---
void recibir_comando(String comando) {
  if (comando.length() == 0) return;

  char c = comando[0];

  switch (c) {
    case 'A':
      drawInMatrix(LED_CaraFeliz, 3);
      break;
    case 'B':
      drawInMatrix(LED_PacMan, 3);
      break;
    case 'C':
      drawInMatrix(LED_si, 3);
      break;
    case 'D':
      drawInMatrix(LED_no, 3);
      break;
    default:
      // Comando desconocido: apagar matriz
      matrix.clear();
      break;
  }
}

void setup() {
  matrix.begin();
  matrix.setGrayscaleBits(3);
  matrix.clear(); // Apagar la matriz al inicio

  Bridge.begin();
  Bridge.provide("recibir_comando", recibir_comando);
}

void loop() {
  // El Bridge maneja los eventos de forma asíncrona
}
