// Botón actualmente activo
let botonActivo = null;

function enviarModo(e, modo) {
  const boton = e.currentTarget;

  // Marcar el botón como activo visualmente
  if (botonActivo) {
    botonActivo.classList.remove("activo");
  }
  botonActivo = boton;
  boton.classList.add("activo");

  // Deshabilitar todos los botones mientras se envía
  const botones = document.querySelectorAll("button");
  botones.forEach(b => b.disabled = true);

  fetch("/enviar", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ texto: modo })
  })
  .then(res => {
    if (!res.ok) throw new Error("Error al enviar: " + res.status);
    console.log("Enviado:", modo);
    mostrarEstado("✅ Modo enviado: " + modo, false);
  })
  .catch(err => {
    console.error(err);
    mostrarEstado("❌ Error al conectar con el servidor", true);
    // Revertir estado del botón si falla
    boton.classList.remove("activo");
    botonActivo = null;
  })
  .finally(() => {
    botones.forEach(b => b.disabled = false);
  });
}

function mostrarEstado(mensaje, esError) {
  let estado = document.getElementById("estado");
  if (!estado) {
    estado = document.createElement("p");
    estado.id = "estado";
    document.body.appendChild(estado);
  }
  estado.textContent = mensaje;
  estado.style.color = esError ? "#ff4444" : "#00ff88";

  // Ocultar el mensaje después de 3 segundos
  clearTimeout(estado._timeout);
  estado._timeout = setTimeout(() => {
    estado.textContent = "";
  }, 3000);
}