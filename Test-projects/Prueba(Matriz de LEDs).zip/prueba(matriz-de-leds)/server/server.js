const express = require('express');
const { SerialPort } = require('serialport');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

const puertoArduino = 'COM3'; // Windows
// const puertoArduino = '/dev/ttyUSB0'; // Linux

const port = new SerialPort({
  path: puertoArduino,
  baudRate: 9600
});

app.post('/enviar', (req, res) => {
  const mensaje = req.body.texto;

  console.log("Enviando:", mensaje);

  port.write(mensaje);

  res.send("ok");
});

app.listen(3000, () => {
  console.log("Servidor corriendo en http://localhost:3000");
});