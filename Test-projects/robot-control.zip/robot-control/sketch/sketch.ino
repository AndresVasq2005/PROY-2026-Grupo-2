// ============================================================
//  Robot Control - Motores + Matriz de LEDs
//  Pines L298N:  IN1=2, IN2=3 (motor derecho)
//                IN3=4, IN4=5 (motor izquierdo)
// ============================================================

#include <Arduino_LED_Matrix.h>
#include <Arduino_RouterBridge.h>

#define IN1 2
#define IN2 3
#define IN3 4
#define IN4 5

// ------- Patrones de LEDs -------
uint8_t LED_Adelante[104] = {
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,7,7,7,0,0,0,0,0,
  0,0,0,0,7,7,7,7,7,0,0,0,0,
  0,0,0,7,0,0,7,0,0,7,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0
};

uint8_t LED_Atras[104] = {
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,7,0,0,7,0,0,7,0,0,0,
  0,0,0,0,7,7,7,7,7,0,0,0,0,
  0,0,0,0,0,7,7,7,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0
};

uint8_t LED_Der[104] = {
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,7,0,0,0,0,
  0,0,0,0,0,0,0,0,7,7,0,0,0,
  0,0,7,7,7,7,7,7,7,7,7,0,0,
  0,0,7,7,7,7,7,7,7,7,7,0,0,
  0,0,0,0,0,0,0,0,7,7,0,0,0,
  0,0,0,0,0,0,0,0,7,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0
};

uint8_t LED_Izq[104] = {
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,7,0,0,0,0,0,0,0,0,
  0,0,0,7,7,0,0,0,0,0,0,0,0,
  0,0,7,7,7,7,7,7,7,7,7,0,0,
  0,0,7,7,7,7,7,7,7,7,7,0,0,
  0,0,0,7,7,0,0,0,0,0,0,0,0,
  0,0,0,0,7,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0
};

uint8_t LED_Stop[104] = {
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,7,7,7,7,7,7,7,7,7,0,0,
  0,0,7,0,0,0,0,0,0,0,7,0,0,
  0,0,7,0,7,7,7,7,7,0,7,0,0,
  0,0,7,0,7,7,7,7,7,0,7,0,0,
  0,0,7,0,0,0,0,0,0,0,7,0,0,
  0,0,7,7,7,7,7,7,7,7,7,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0
};

Arduino_LED_Matrix matrix;
int tiempoMovimiento = 0; // ms que queda por moverse
unsigned long ultimoTick = 0;
char movimientoActual = 'S';

void detener() {
  digitalWrite(IN1, LOW); digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW); digitalWrite(IN4, LOW);
}

void adelante() {
  digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW);
  digitalWrite(IN3, HIGH); digitalWrite(IN4, LOW);
}

void atras() {
  digitalWrite(IN1, LOW); digitalWrite(IN2, HIGH);
  digitalWrite(IN3, LOW); digitalWrite(IN4, HIGH);
}

void girarDer() {
  digitalWrite(IN1, LOW);  digitalWrite(IN2, LOW);
  digitalWrite(IN3, HIGH); digitalWrite(IN4, LOW);
}

void girarIzq() {
  digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);  digitalWrite(IN4, LOW);
}

void mostrarLED(uint8_t* patron) {
  matrix.setGrayscaleBits(3);
  matrix.draw(patron);
}

// Llamado desde Python: "F:1500" = adelante por 1500 ms
void recibir_comando(String cmd) {
  if (cmd.length() == 0) return;

  int separador = cmd.indexOf(':');
  char accion = cmd[0];
  tiempoMovimiento = 0;

  if (separador > 0) {
    tiempoMovimiento = cmd.substring(separador + 1).toInt();
  }

  movimientoActual = accion;
  ultimoTick = millis();

  switch (accion) {
    case 'F': adelante();  mostrarLED(LED_Adelante); break;
    case 'B': atras();     mostrarLED(LED_Atras);    break;
    case 'R': girarDer();  mostrarLED(LED_Der);      break;
    case 'L': girarIzq();  mostrarLED(LED_Izq);      break;
    case 'S': default:
      detener();
      mostrarLED(LED_Stop);
      tiempoMovimiento = 0;
      break;
  }
}

void setup() {
  pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  detener();

  matrix.begin();
  matrix.setGrayscaleBits(3);
  mostrarLED(LED_Stop);

  Bridge.begin();
  Bridge.provide("recibir_comando", recibir_comando);
}

void loop() {
  // Si hay un tiempo límite y ya pasó, detener
  if (tiempoMovimiento > 0 && movimientoActual != 'S') {
    if ((millis() - ultimoTick) >= (unsigned long)tiempoMovimiento) {
      detener();
      mostrarLED(LED_Stop);
      movimientoActual = 'S';
      tiempoMovimiento = 0;
    }
  }
}
