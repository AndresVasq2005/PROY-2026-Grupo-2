// ── Estado ────────────────────────────────────────────────
let moviendose     = false;
let timerContinuo  = null;   // Para movimiento continuo (pulsar y mantener)
let botonActual    = null;

// ── Helpers ───────────────────────────────────────────────
function getCm() {
  const v = parseInt(document.getElementById('cm-input').value, 10);
  return isNaN(v) || v < 0 ? 0 : v;
}

function ajustarCm(delta) {
  const input = document.getElementById('cm-input');
  const nuevo = Math.max(0, Math.min(999, (parseInt(input.value) || 0) + delta));
  input.value = nuevo;
}

function setBadge(texto, tipo) {
  const b = document.getElementById('estado-badge');
  b.textContent = texto;
  b.className = 'badge badge-' + tipo;
}

function log(msg, tipo = 'info') {
  const box = document.getElementById('log');
  const t = new Date().toLocaleTimeString('es-CL', { hour12: false });
  const div = document.createElement('div');
  div.className = 'log-' + tipo;
  div.textContent = `[${t}] ${msg}`;
  box.prepend(div);
  // Mantener máximo 30 entradas
  while (box.children.length > 30) box.removeChild(box.lastChild);
}

// ── Enviar comando al servidor ─────────────────────────────
async function enviar(direccion, cm) {
  try {
    const res = await fetch('/mover', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ direccion, cm }),
    });

    const data = await res.json();

    if (!res.ok || !data.ok) throw new Error(data.error || 'Error desconocido');

    if (direccion === 'parar') {
      setBadge('DETENIDO', 'idle');
      log('⏹ Detenido', 'info');
    } else {
      setBadge('MOVIENDO', 'moving');
      const cmStr = cm > 0 ? ` (${cm} cm)` : ' continuo';
      log(`▶ ${direccion.toUpperCase()}${cmStr}`, 'ok');
    }

  } catch (err) {
    setBadge('ERROR', 'error');
    log('❌ ' + err.message, 'error');
    console.error(err);
  }
}

// ── Manejo de botones ─────────────────────────────────────
function iniciarMovimiento(direccion) {
  const cm = getCm();
  const btnId = 'btn-' + direccion;
  const btn   = document.getElementById(btnId);

  // Marcar visualmente
  if (botonActual) botonActual.classList.remove('presionado');
  botonActual = btn;
  btn.classList.add('presionado');

  if (cm > 0) {
    // Modo cm: enviar una sola vez y liberar el botón cuando termine
    moviendose = true;
    enviar(direccion, cm).then(() => {
      // Después del tiempo estimado, el Arduino para solo
      // Actualizamos la UI con un pequeño margen
      const ms = (cm / 20) * 1000 + 400;
      setTimeout(() => {
        setBadge('DETENIDO', 'idle');
        if (botonActual) botonActual.classList.remove('presionado');
        botonActual = null;
        moviendose = false;
      }, ms);
    });
  } else {
    // Modo continuo: enviar y repetir mientras el botón esté presionado
    moviendose = true;
    enviar(direccion, 0);
    timerContinuo = setInterval(() => enviar(direccion, 0), 1500);
  }
}

function soltarBoton() {
  if (!moviendose) return;

  clearInterval(timerContinuo);
  timerContinuo = null;

  const cm = getCm();
  if (cm === 0) {
    // Solo parar si era movimiento continuo
    enviar('parar', 0);
    if (botonActual) botonActual.classList.remove('presionado');
    botonActual = null;
  }
  // Si era por cm, el Arduino para solo; ya se maneja en iniciarMovimiento
  moviendose = false;
}

// ── Teclado (para escritorio) ──────────────────────────────
const teclaMap = {
  'ArrowUp':    'adelante',
  'ArrowDown':  'atras',
  'ArrowLeft':  'izquierda',
  'ArrowRight': 'derecha',
};
const teclasPresionadas = new Set();

document.addEventListener('keydown', (e) => {
  const dir = teclaMap[e.key];
  if (dir && !teclasPresionadas.has(e.key)) {
    teclasPresionadas.add(e.key);
    iniciarMovimiento(dir);
  }
  if (e.key === ' ') { e.preventDefault(); enviar('parar', 0); }
});

document.addEventListener('keyup', (e) => {
  const dir = teclaMap[e.key];
  if (dir) {
    teclasPresionadas.delete(e.key);
    soltarBoton();
  }
});

// ── Init ──────────────────────────────────────────────────
log('Sistema listo 🤖', 'ok');
