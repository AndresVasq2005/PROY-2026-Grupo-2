from arduino.app_bricks.web_ui import WebUI
from arduino.app_utils import App, Bridge, Logger

logger = Logger("robot-control")

# ── Configuración WebUI ──────────────────────────────────────────────────────
ui = WebUI(
    port=7000,
    assets_dir_path="./web",
)

logger.info("Servidor Robot Control iniciado en puerto 7000")

# ── Constantes ───────────────────────────────────────────────────────────────
# Velocidad aproximada del robot en cm/s (ajusta según tu robot)
CM_POR_SEGUNDO = 20.0

COMANDOS = {
    "adelante": "F",
    "atras":    "B",
    "derecha":  "R",
    "izquierda":"L",
    "parar":    "S",
}


# ── API Endpoints ─────────────────────────────────────────────────────────────

def mover(payload: dict):
    """
    Payload esperado:
      { "direccion": "adelante"|"atras"|"derecha"|"izquierda"|"parar",
        "cm": <número opcional, 0 = continuo> }
    """
    direccion = payload.get("direccion", "parar")
    cm        = float(payload.get("cm", 0))

    if direccion not in COMANDOS:
        return {"ok": False, "error": f"Dirección '{direccion}' no reconocida"}

    letra = COMANDOS[direccion]

    if letra == "S" or cm <= 0:
        # Comando continuo o parar
        cmd = letra
    else:
        # Calcular milisegundos necesarios para recorrer los cm dados
        ms = int((cm / CM_POR_SEGUNDO) * 1000)
        cmd = f"{letra}:{ms}"

    logger.info(f"Enviando: {cmd}")
    Bridge.call("recibir_comando", cmd)

    return {"ok": True, "comando": cmd}


ui.expose_api("POST", "/mover", mover)

App.run()
