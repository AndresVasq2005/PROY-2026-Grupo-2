# 🤖 Robot Controller — Control unificado por Wi-Fi

Controla los motores y la matriz LED de tu Arduino UNO R4 WiFi desde el celular.

## Estructura

```
robot-controller/
├── web/
│   └── index.html     ← Interfaz web (motores + LED)
├── python/
│   └── main.py        ← Servidor unificado
└── sketch/
    └── sketch.ino     ← Arduino: motores + LED con Bridge
```

## Cómo funciona

```
Celular (index.html) → fetch POST → main.py → Bridge.call() → sketch.ino → motores / LEDs
```

## Conexiones del motor (L298N)

| Pin Arduino | Pin L298N | Motor         |
|-------------|-----------|---------------|
| D2 (IN1)    | IN1       | Derecho — FWD |
| D3 (IN2)    | IN2       | Derecho — BWD |
| D4 (IN3)    | IN3       | Izquierdo — FWD |
| D5 (IN4)    | IN4       | Izquierdo — BWD |

## Endpoints API

| Método | URL       | Body                          | Acción             |
|--------|-----------|-------------------------------|--------------------|
| POST   | /mover    | `{"cmd": "adelante"}`         | Mueve el robot     |
| POST   | /led      | `{"patron": "A"}`             | Muestra patrón LED |
| POST   | /led/off  | `{}`                          | Apaga la matriz    |

Comandos de movimiento: `adelante`, `atras`, `derecha`, `izquierda`, `stop`
Patrones LED: `A` = Cara Feliz, `B` = Pacman, `C` = Sí, `D` = No

## Patrones LED en movimiento

Cuando el robot se mueve, los LEDs muestran automáticamente una flecha direccional:
- Adelante → flecha ↑
- Atrás → flecha ↓
- Derecha → flecha →
- Izquierda → flecha ←
- Stop → cuadrado ■

## Agregar nuevo movimiento / patrón

1. **sketch.ino**: agregar `else if (cmd == "mi_cmd") { ... }` en `void mover()`
2. **main.py**: agregar el string al set `MOVIMIENTOS`
3. **index.html**: agregar un botón con `onclick="move('mi_cmd')"`
