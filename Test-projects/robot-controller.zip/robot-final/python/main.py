"""
Robot Controller — main.py
===========================
Servidor unificado para controlar motores y matriz LED
a través del Bridge de Arduino App Lab.

Endpoints:
  POST /mover     → { "cmd": "adelante"|"atras"|"derecha"|"izquierda"|"stop" }
  POST /led       → { "patron": "A"|"B"|"C"|"D" }
  POST /led/off   → {}
"""

from arduino.app_bricks.web_ui import WebUI
from arduino.app_utils import App, Bridge, Logger

logger = Logger("robot-controller")

ui = WebUI(
    port=7000,
    assets_dir_path="./web",
)

# ── Motores ───────────────────────────────────────────────────────────────────

MOVIMIENTOS = {"adelante", "atras", "derecha", "izquierda", "stop"}

def mover(payload: dict):
    cmd = payload.get("cmd", "").lower().strip()
    if cmd not in MOVIMIENTOS:
        logger.warning(f"Movimiento desconocido: '{cmd}'")
        return {"ok": False, "error": f"Comando '{cmd}' no válido"}
    logger.info(f"Movimiento: {cmd}")
    Bridge.call("mover", cmd)
    return {"ok": True, "cmd": cmd}

# ── Matriz LED ────────────────────────────────────────────────────────────────

PATRONES = {"A": "Cara Feliz", "B": "Pacman", "C": "Sí", "D": "No"}

def led_patron(payload: dict):
    patron = payload.get("patron", "").upper()
    if patron not in PATRONES:
        return {"ok": False, "error": f"Patrón '{patron}' no reconocido"}
    logger.info(f"LED patrón: {patron} ({PATRONES[patron]})")
    Bridge.call("led_patron", patron)
    return {"ok": True, "patron": PATRONES[patron]}

def led_off(payload: dict):
    logger.info("LED apagado")
    Bridge.call("led_apagar", "")
    return {"ok": True}

# ── Registrar endpoints ───────────────────────────────────────────────────────

ui.expose_api("POST", "/mover",    mover)
ui.expose_api("POST", "/led",      led_patron)
ui.expose_api("POST", "/led/off",  led_off)

logger.info("Robot Controller iniciado en puerto 7000")
App.run()
