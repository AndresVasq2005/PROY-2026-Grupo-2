#include <Arduino_RouterBridge.h>
#include <Arduino_LED_Matrix.h>

// ── Pines del driver L298N ────────────────────────────────────────────────────
#define IN1 2   // Motor derecho - dirección A
#define IN2 3   // Motor derecho - dirección B
#define IN3 4   // Motor izquierdo - dirección A
#define IN4 5   // Motor izquierdo - dirección B

// ── Instancia de la matriz LED ────────────────────────────────────────────────
Arduino_LED_Matrix matrix;

// ── Patrones de LEDs (8 filas × 13 columnas = 104 píxeles) ───────────────────
uint8_t LED_CaraFeliz[104] = {
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,7,7,0,0,0,0,0,0,0,7,7,0,
  0,7,7,0,0,0,0,0,0,0,7,7,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,7,0,0,0,0,0,7,0,0,0,
  0,0,0,0,7,0,0,0,7,0,0,0,0,
  0,0,0,0,0,7,7,7,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0
};

uint8_t LED_PacMan[104] = {
  0,0,0,0,7,7,7,7,0,0,0,0,0,
  0,0,0,7,7,7,7,7,7,0,0,0,0,
  0,0,7,7,7,7,7,7,7,7,0,0,0,
  0,7,7,7,7,7,0,0,0,0,0,0,0,
  0,7,7,7,7,7,0,0,0,0,0,0,0,
  0,0,7,7,7,7,7,7,7,7,0,0,0,
  0,0,0,7,7,7,7,7,7,0,0,0,0,
  0,0,0,0,7,7,7,7,0,0,0,0,0
};

uint8_t LED_Si[104] = {
  0,0,0,0,2,7,7,7,2,0,0,0,0,
  0,0,0,2,7,2,2,2,7,2,0,0,0,
  0,0,2,7,2,0,0,0,2,7,2,0,0,
  0,0,2,7,2,0,0,0,2,7,2,0,0,
  0,0,2,7,2,0,0,0,2,7,2,0,0,
  0,0,2,7,2,0,0,0,2,7,2,0,0,
  0,0,0,2,7,2,2,2,7,2,0,0,0,
  0,0,0,0,2,7,7,7,2,0,0,0,0
};

uint8_t LED_No[104] = {
  0,0,0,7,2,0,0,0,2,7,0,0,0,
  0,0,0,2,7,2,0,2,7,2,0,0,0,
  0,0,0,0,2,7,2,7,2,0,0,0,0,
  0,0,0,0,0,2,7,2,0,0,0,0,0,
  0,0,0,0,0,2,7,2,0,0,0,0,0,
  0,0,0,0,2,7,2,7,2,0,0,0,0,
  0,0,0,2,7,0,0,2,7,2,0,0,0,
  0,0,0,7,2,0,0,0,2,7,0,0,0
};

uint8_t LED_Adelante[104] = {
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,7,7,7,0,0,0,0,0,
  0,0,0,0,7,7,7,7,7,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0
};

uint8_t LED_Atras[104] = {
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,7,7,7,7,7,0,0,0,0,
  0,0,0,0,0,7,7,7,0,0,0,0,0,
  0,0,0,0,0,0,7,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0
};

uint8_t LED_Derecha[104] = {
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,7,0,0,0,
  0,7,0,0,0,0,0,0,7,7,0,0,0,
  0,7,7,7,7,7,7,7,7,7,0,0,0,
  0,7,7,7,7,7,7,7,7,7,0,0,0,
  0,7,0,0,0,0,0,0,0,7,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0
};

uint8_t LED_Izquierda[104] = {
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,7,0,0,0,0,0,0,0,0,0,
  0,0,0,7,7,0,0,0,0,0,0,7,0,
  0,0,0,7,7,7,7,7,7,7,7,7,0,
  0,0,0,7,7,7,7,7,7,7,7,7,0,
  0,0,0,7,0,0,0,0,0,0,0,7,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0
};

uint8_t LED_Stop[104] = {
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,7,7,7,7,7,7,7,7,7,0,0,
  0,0,7,0,0,0,0,0,0,0,7,0,0,
  0,0,7,0,7,7,7,7,7,0,7,0,0,
  0,0,7,0,7,7,7,7,7,0,7,0,0,
  0,0,7,0,0,0,0,0,0,0,7,0,0,
  0,0,7,7,7,7,7,7,7,7,7,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0
};

// ── Helpers de motor ──────────────────────────────────────────────────────────
void motorDerecho(bool fwd, bool bwd) {
  digitalWrite(IN1, fwd ? HIGH : LOW);
  digitalWrite(IN2, bwd ? HIGH : LOW);
}

void motorIzquierdo(bool fwd, bool bwd) {
  digitalWrite(IN3, fwd ? HIGH : LOW);
  digitalWrite(IN4, bwd ? HIGH : LOW);
}

void detener() {
  motorDerecho(false, false);
  motorIzquierdo(false, false);
}

// ── Proveedores Bridge: MOTORES ───────────────────────────────────────────────

void mover(String cmd) {
  if      (cmd == "adelante")  { motorDerecho(true,false);  motorIzquierdo(true,false);  matrix.setGrayscaleBits(3); matrix.draw(LED_Adelante); }
  else if (cmd == "atras")     { motorDerecho(false,true);  motorIzquierdo(false,true);  matrix.setGrayscaleBits(3); matrix.draw(LED_Atras); }
  else if (cmd == "derecha")   { motorDerecho(false,false); motorIzquierdo(true,false);  matrix.setGrayscaleBits(3); matrix.draw(LED_Derecha); }
  else if (cmd == "izquierda") { motorDerecho(true,false);  motorIzquierdo(false,false); matrix.setGrayscaleBits(3); matrix.draw(LED_Izquierda); }
  else if (cmd == "stop")      { detener(); matrix.setGrayscaleBits(3); matrix.draw(LED_Stop); }
}

// ── Proveedores Bridge: MATRIZ LED ───────────────────────────────────────────

void led_patron(String patron) {
  matrix.setGrayscaleBits(3);
  if      (patron == "A") matrix.draw(LED_CaraFeliz);
  else if (patron == "B") matrix.draw(LED_PacMan);
  else if (patron == "C") matrix.draw(LED_Si);
  else if (patron == "D") matrix.draw(LED_No);
  else                    matrix.clear();
}

void led_apagar(String _) {
  matrix.clear();
}

// ── setup ─────────────────────────────────────────────────────────────────────
void setup() {
  // Pines de motor
  pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  detener();

  // Matriz LED
  matrix.begin();
  matrix.setGrayscaleBits(3);
  matrix.clear();

  // Bridge
  Bridge.begin();
  Bridge.provide("mover",      mover);
  Bridge.provide("led_patron", led_patron);
  Bridge.provide("led_apagar", led_apagar);
}

void loop() {
  // Bridge maneja todo de forma asíncrona
}
