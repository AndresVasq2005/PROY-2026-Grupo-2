#define TRIG 9
#define ECHO 10

void setup() {
  Serial.begin(9600);
  delay(2000);

  pinMode(TRIG, OUTPUT);
  pinMode(ECHO, INPUT);

  Serial.println("Sensor iniciado");
}

void loop() {
  digitalWrite(TRIG, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG, LOW);

  unsigned long duracion = pulseIn(ECHO, HIGH, 30000);

  Serial.print("Duracion: ");
  Serial.print(duracion);
  Serial.print(" us | ");

  if (duracion == 0 || duracion > 30000) {
    Serial.println("Sin lectura / fuera de rango");
  } else {
    unsigned long distancia_cm = duracion / 58;

    Serial.print("Distancia: ");
    Serial.print(distancia_cm);
    Serial.println(" cm");
  }

  delay(500);
}