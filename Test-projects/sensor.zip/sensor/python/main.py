import time

print("App iniciada")

while True:
    time.sleep(1)