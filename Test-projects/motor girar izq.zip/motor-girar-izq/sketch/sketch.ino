#define IN1 2
#define IN2 3
#define IN3 4
#define IN4 5

void setup() {

  digitalWrite(IN1, LOW);
  digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, LOW);

  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT);
  pinMode(IN4, OUTPUT);

  delay(500);
}

void loop() {

  // Motor derecho adelante
  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);

  // Motor izquierdo detenido
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, LOW);
}