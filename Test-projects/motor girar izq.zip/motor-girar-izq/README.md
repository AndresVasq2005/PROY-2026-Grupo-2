# 😀 motor girar izq




